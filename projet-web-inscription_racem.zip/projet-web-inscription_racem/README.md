# projet-web

j'ai réorganisé la hiérarchie du projet pour être plus ordonné . J'ai introduit
un service de mailing pour confirmer toutes inscriptions à notre site web. Pour
tester le service de mailing il faut que vous essayer en localhost , changer le
numéro du port dans le fichier PHP_classes/MailConfirmation.php Si , l'adresse
et le mot de passe du compte mail ne sont pas affichés svp me contacter pour
vous fournir des coordonnées . La base de donnée en localhost doit être nommée
"projetweb" et la table "students" qui possède les colonnes suivantes : email /
code_unique / first_name / last_name / password / confirmation . Aussi , il faut
avoir le composer installé
