<?php

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../Assets/styling/bootstrapCyborg.min.css">
    <link rel="stylesheet" href="../Assets/styling/styleGoCheckYourEmail.css">
    <title>Sign Up</title>

</head>
<body>

<div class=" container alert alert-dismissible alert-success">

    <h4 class="alert-heading">Success!</h4>
    <p class="mb-0"><strong>Congratulations.</strong> <br> your account is confirmed ! <br>

    <h4>start learning from now</h4></p>
    <button type="button" class="btn btn-lg btn-warning"><a href="login.php"> login</a></button>
</div>

</body>
</html>
