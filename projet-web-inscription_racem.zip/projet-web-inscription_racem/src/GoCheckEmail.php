<?php

?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../Assets/styling/bootstrapCyborg.min.css">
    <link rel="stylesheet" href="../Assets/styling/styleGoCheckYourEmail.css">
    <title>Sign Up</title>

</head>
<body>

<div class=" container alert alert-dismissible alert-success">

    <h4 class="alert-heading">Success!</h4>
    <p class="mb-0"><strong>Sign up succeded.</strong> <br> please check your email to confirm your account <br>

    <h3>waiting for you as soon as possible !</h3></p>
</div>
</div>
</body>
</html>
